<?php

?>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery-ui/jquery-ui-1.10.1.custom.min.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/bs3/js/bootstrap.min.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.dcjqaccordion.2.7.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.scrollTo.min.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jQuery-slimScroll-1.3.0/jquery.slimscroll.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.nicescroll.js'?>"></script>

<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/skycons/skycons.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.scrollTo/jquery.scrollTo.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.easing.min.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/calendar/clndr.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/underscore-min.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/calendar/moment-2.2.1.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/evnt.calendar.init.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jvector-map/jquery-jvectormap-1.2.2.min.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jvector-map/jquery-jvectormap-us-lcc-en.js'?>"></script>
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/gauge/gauge.js'?>"></script>
<!--clock init-->
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/css3clock/js/css3clock.js'?>"></script>
<!--Easy Pie Chart-->
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/easypiechart/jquery.easypiechart.js'?>"></script>
<!--Sparkline Chart-->
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/sparkline/jquery.sparkline.js'?>"></script>
<!--Morris Chart-->
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/morris-chart/morris.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/morris-chart/raphael-min.js'?>"></script>
<!--jQuery Flot Chart-->
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/flot-chart/jquery.flot.js'?>"></script>
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/flot-chart/jquery.flot.tooltip.min.js'?>"></script>
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/flot-chart/jquery.flot.resize.js'?>"></script>
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/flot-chart/jquery.flot.pie.resize.js'?>"></script>
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/flot-chart/jquery.flot.animator.min.js'?>"></script>
<script src="<?php //echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/flot-chart/jquery.flot.growraf.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/dashboard.js'?>"></script>
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery.customSelect.min.js'?>" ></script>
<!--common script init for all pages-->
<script src="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/scripts.js'?>"></script>