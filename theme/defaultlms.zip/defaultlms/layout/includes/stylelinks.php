<?php

?>
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/bs3/css/bootstrap.min.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jquery-ui/jquery-ui-1.10.1.custom.min.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/css/bootstrap-reset.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/font-awesome/css/font-awesome.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/jvector-map/jquery-jvectormap-1.2.2.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/css/clndr.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/css3clock/css/style.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/js/morris-chart/morris.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/css/style.css'?>"> 
<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/css/style-responsive.css'?>"> 

<link rel="stylesheet" href="<?php echo $CFG->wwwroot.'/theme/defaultlms/layout/includes/css/style-responsive.css'?>"> 
