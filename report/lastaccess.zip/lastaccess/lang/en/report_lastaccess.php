<?php

$string['agency'] = 'Agency';
$string['currentdate'] = 'Current Date';
$string['display'] = 'Display';
$string['error_invaliddate'] = 'Last access date is greater than current date';
$string['error_invalidcourse'] = 'You must select a course from the list provided';
$string['error_invalidcurrentdate'] = 'Current date is greater than system date';
$string['error_nolastaccessdate'] = 'Please enter last access date';
$string['exportcsv'] = 'Export as CSV';
$string['grade'] = 'Grade';
$string['lastaccess'] = 'Last access date';
$string['lastaccess:view'] = 'View activity completion reports';
$string['name'] = 'Name';
$string['nodatareturned'] = 'There are no last accessed reports that much the criteria';
$string['nocourse'] = 'No course available..';
$string['pluginname'] = 'Director Report';
$string['title'] = 'Director Report';

