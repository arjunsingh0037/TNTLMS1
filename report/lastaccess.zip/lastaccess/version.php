<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version   = 2017050200;              // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2014110400;              // Requires this Moodle version
$plugin->component = 'report_lastaccess'; // Full name of the plugin (used for diagnostics)

