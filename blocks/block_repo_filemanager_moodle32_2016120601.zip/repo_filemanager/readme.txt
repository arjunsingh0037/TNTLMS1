repo_filemanager Moodle 2.x block
---------------------------------

This Moodle block has been provided by Tim Williams of AutoTrain e-Learning (tmw@autotrain.org).
It is a re-write of the Moodle 1.x file manager for use within Moodle 2.x. It is primarily intended
for use with the Couse Files Area repository plugin.

This Moodle 2.x block should be installed into the 'blocks' directory within your Moodle installation.

This sofware is covered by the GPLv3 licence.
