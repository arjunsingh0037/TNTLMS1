function set_vmchat_variable(Y, vmopts) {
    wwwroot = vmopts.wwwroot;
    imageurl = vmopts.imageurl;
    sid = vmopts.sid;
    auth_user = vmopts.auth_user;
    auth_pass = vmopts.auth_pass;
    path = vmopts.path;
    tk = vmopts.tk;
    id = vmopts.id;
    fname = vmopts.fname;
    lname = vmopts.lname;
}