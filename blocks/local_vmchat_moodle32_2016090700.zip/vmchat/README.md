moodle-local_vmchat
===================

Moodle - Local plugin for vmchat (footer chat)


This plugin adds a footer chat bar at your site.
Users will be able to chat with other users.

Dependencies
----------------------
Getkey local module is required to run vmchat.


Installation in Moodle
----------------------
* Unzip the zip file and place the vmchat folder in local folder of Moodle.
* Go to Site administration -> Vm chat and activate this module.

Warning
-------------
Elegance theme is not supported

change log for version 2.0
---------------------------
* AMD support added to fix jQuery conflict with themes
* In ipad, Private chat window reset to blank on page refresh has been fixed
* Use of Moodle jQuery
* Removed code embedding in additional html header

