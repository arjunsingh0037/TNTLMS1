/*language file*/
define(function () {
    return {
        online: "Online Users",
        whos: "Who's online",
        chatroom: "Chatroom",
        chatroom_header: "Common Chat",
        error: "Something bad happend. Sorry!",
        wserror: "Browser does not support WebSocket",
        sterror: "This browser doesn't support Web Storage standard"
    }
});