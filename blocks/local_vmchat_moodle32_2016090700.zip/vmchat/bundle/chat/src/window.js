define(function(){
   return window;
});