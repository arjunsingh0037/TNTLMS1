chat
======

Chat - Core module for footer chat
