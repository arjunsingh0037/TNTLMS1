This block allows you to manage students projects im Moodle 2.7

To install:

1/ Copy folder to blocks folder.
2/ Go to "Notifications" to install it.


To use:

1/ Create a forum that uses groups
2/ Create a chat that uses groups
3/ Create the block inside the course
4/ Edit the block to define dates and to relate chat and forum to the project.

