.simplehtml.displaydate {
    font-size: .8em;
    text-align: center;
}