# CHANGES #

## 1.0.0 ##

* Initial implementation of the plugin, first public release.
