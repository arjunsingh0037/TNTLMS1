SMS Notification Block

Author: Azmat Ullah, Talha Noor

Plugin Instalation

1) Copy plugin folder in moodle blocks folder
2) Login with Administrator on Moodle site
3) Install the plugin by clicking on 'update database' now button
4) Put SMS API ID, username and password in setting page


Clickatell
For Clickatell API, See http://www.clickatell.com
_________________________________
1) Create a developer account on Clickatell.com
2) Login with developer account
3) Click on Manage my Products tab
4) Copy API ID and paste it on Moodle setting page with username and password


Sendsms.pk(This API will only work in Pakistan)
For Send SMS API, See http://www.sendsms.pk/
_________________________________
1) Create an account on sendsms.pk
2) Login with account
3) Click SMS API under setting link
4) Copy API ID and paste it on Moodle setting page with username and password

