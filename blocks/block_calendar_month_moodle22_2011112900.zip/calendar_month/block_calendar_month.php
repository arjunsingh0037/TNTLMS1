<?php

class block_calendar_month extends block_base {
    function init() {
        $this->title = get_string('pluginname', 'block_calendar_month');
    }

    function preferred_width() {
        return 210;
    }

    function get_content() {
        global $USER, $CFG, $SESSION;
        $cal_m = optional_param( 'cal_m', 0, PARAM_INT );
        $cal_y = optional_param( 'cal_y', 0, PARAM_INT );

        require_once($CFG->dirroot.'/calendar/lib.php');

        if ($this->content !== NULL) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';

        // [pj] To me it looks like this if would never be needed, but Penny added it
        // when committing the /my/ stuff. Reminder to discuss and learn what it's about.
        // It definitely needs SOME comment here!
        $courseid = $this->page->course->id;
        $issite = ($courseid == SITEID);

        if ($issite) {
            // Being displayed at site level. This will cause the filter to fall back to auto-detecting
            // the list of courses it will be grabbing events from.
            $filtercourse = calendar_get_default_courses();
        } else {
            // Forcibly filter events to include only those from the particular course we are in.
            $filtercourse = array($courseid => $this->page->course);
        }

        list($courses, $group, $user) = calendar_set_filters($filtercourse);
// vvv
        $this->content->text .='<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-bottom:1px solid #ddd;"><tr><td width="70" style="padding:0">
		<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" CODEBASE="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="55" HEIGHT="55">
		<PARAM NAME="movie" VALUE="'.$CFG->wwwroot.'/blocks/calendar_month/clock.swf">
		<PARAM NAME="quality" VALUE="high">
		<param name="play" value="true">
		<param name="loop" value="true">
		<PARAM NAME="wmode" VALUE="transparent">
		<PARAM NAME="menu" VALUE="false">
		<EMBED src="'.$CFG->wwwroot.'/blocks/calendar_month/clock.swf" quality="high" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer" WIDTH="55" HEIGHT="55" wmode="transparent" menu="false">
		</EMBED>
		</OBJECT>
	</td><td style="padding:0"><h3>'.
	userdate(mktime(), get_string('strftimedayshort'))
	.'</h3></td></tr></table>
	';
        if ($issite) {
            // For the front page
            $this->content->text .= calendar_top_controls('frontpage', array('id' => $courseid, 'm' => $cal_m, 'y' => $cal_y));
// vvv
            $this->content->text=str_replace('<a class="arrow','<a onClick="that=this;YAHOO.util.Connect.asyncRequest(\'GET\', this.href=\''.$CFG->wwwroot.'/blocks/calendar_month/index.php\'+this.href.substr(this.href.indexOf(\'?\')), { success:function(t){pn=that.parentNode.parentNode; pn.innerHTML=t.responseText;s=pn.getElementsByTagName(\'script\');eval(s[0].text);} } );return false;" class="arrow',$this->content->text);
            $this->content->text .= calendar_get_mini($courses, $group, $user, $cal_m, $cal_y);
            // No filters for now
        } else {
            // For any other course
            $this->content->text .= calendar_top_controls('course', array('id' => $courseid, 'm' => $cal_m, 'y' => $cal_y));
// vvv
            $this->content->text=str_replace('<a class="arrow','<a onClick="that=this;YAHOO.util.Connect.asyncRequest(\'GET\', this.href=\''.$CFG->wwwroot.'/blocks/calendar_month/index.php\'+this.href.substr(this.href.indexOf(\'?\')), { success:function(t){pn=that.parentNode.parentNode; pn.innerHTML=t.responseText;s=pn.getElementsByTagName(\'script\');eval(s[0].text);} } );return false;" class="arrow',$this->content->text);
            $this->content->text .= calendar_get_mini($courses, $group, $user, $cal_m, $cal_y);
            $this->content->text .= '<h3 class="eventskey">'.get_string('eventskey', 'calendar').'</h3>';
            $this->content->text .= '<div class="filters">'.calendar_filter_controls($this->page->url).'</div>';
        }

        return $this->content;
    }
}


